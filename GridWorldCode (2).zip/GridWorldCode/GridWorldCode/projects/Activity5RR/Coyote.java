import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;

public class Coyote extends Critter
{
	private int numStep;
	private int sleepCount;
	private boolean walkedIntoWall;
	
	public Coyote()
	{
		numStep = 5;
		sleepCount = 0;
		walkedIntoWall = false;
		setColor(null);
		int[] dir = {Location.NORTH, Location.NORTHEAST, 
					 Location.SOUTH, Location.SOUTHEAST,
					 Location.EAST,	 Location.NORTHWEST,
					 Location.WEST,  Location.SOUTHWEST};
		int n = (int) (Math.random() * dir.length);
		setDirection(dir[n]);
	}
	
	public void processActors(ArrayList<Actor> actors)
    {
        return;
    }
    
    public ArrayList<Location> getMoveLocations()
    {
		ArrayList<Location> locs = new ArrayList<Location>();
		Location next = getLocation().getAdjacentLocation(getDirection());
		if (getGrid().isValid(next)) locs.add(next);
		return locs;
	}
	
	public Location getEmptyAdjacentLocationsAtRandom(){
		ArrayList<Location> nextLocs = getGrid().getEmptyAdjacentLocations(getLocation());
		int n = (int) (Math.random() * nextLocs.size());
		return nextLocs.get(n);
	}
	
	public void makeMove(Location loc)
    {
		if (sleepCount > 0){ // Coyote is in sleeping mode
			if (sleepCount == 5){ // Done sleeping
				numStep = 0;
				sleepCount = 0;
				
				if (!walkedIntoWall){
					Location locForStone = getEmptyAdjacentLocationsAtRandom();
					Stone stone = new Stone();
					stone.putSelfInGrid(getGrid(), locForStone);
				}
				
				Location next = getEmptyAdjacentLocationsAtRandom();
				setDirection(getLocation().getDirectionToward(next));
				
				walkedIntoWall = false;
			}
			else sleepCount++; // Keep sleeping
			return;
		}
		
		// Invalid next location so just sleep
		if (loc.equals(getLocation())){
			sleepCount = 1;
			walkedIntoWall = true;
		}
		else{
			if (getGrid().get(loc) != null){ // There is a actor in front of coyote
				if (getGrid().get(loc) instanceof Boulder){ // The actor is a boulder, coyote is removed
					Kaboom kaboom = new Kaboom();
					kaboom.putSelfInGrid(getGrid(), loc);
					removeSelfFromGrid();
					return;
				}
				else sleepCount = 1; // The actor is not a boulder, coyote sleeps
			}
			else{
				if (numStep < 5){ // Haven't walked 5 steps in a row
					super.makeMove(loc);
					numStep++;
				}
				else sleepCount = 1; // Have walked 5 steps in a row, so coyote sleeps
			}
			
		}
    }
}
