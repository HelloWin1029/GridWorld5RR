/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Cay Horstmann
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 */

import info.gridworld.actor.Bug;

/**
 * A <code>DancingBug</code> traces out a dancing pattern based on turns array. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class DancingBug extends Bug
{
    private int[] turns;
    private int index;

    /**
     * Constructs a DancingBug that traces a dancing pattern based on turns array
     */
    public DancingBug()
    {
        turns = new int[]{ 1, 0, 0, 0, 1, 0, 0, 3, 4,
                           4, 0, 0, 1, 0, 3, 2, 0, 7,
                           0, 0, 0, 3, 2, 1 };
        index = 0;
    }

    /**
     * Moves to the next location of the pattern.
     */
    public void act()
    {
        for (int i = 0; i < turns[index]; i++) turn();
        index = (index + 1) % turns.length;
        if (canMove()) move();
    }
}
