import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Actor;

import java.awt.Color;

public class Jumper extends Bug
{
	private int maxStraightDist;
	private int currentDist;
	
	/**
     * Constructs a blue jumper.
     */
	public Jumper(){ this(10); }
	
	public Jumper(int maxStraightDist){
		super(Color.BLUE);
		this.maxStraightDist = maxStraightDist;
		this.currentDist = 0;
	}
	
	/**
     * Moves if it can move, turns otherwise.
     */
    public void act()
    {
		Grid<Actor> gr = getGrid();
		if (gr == null)
			return;
			
		if (canJump()){
			jump();
			currentDist += 2;
		}
		else{
			boolean jumped = false;
			for (int i = 0; i < 8; i++){
				turn();
				if (canJump()){
					jump();
					currentDist += 2;
					jumped = true;
					break;
				}
			}
			if (!jumped){
				if (canMove()){
					move();
					currentDist++;
					
					Location loc = getLocation();
					int lifetime = (int)(Math.random() * 20);
					Blossom blossom = new Blossom(lifetime);
					blossom.putSelfInGrid(gr, loc);
				}
				else{
					turn();
					currentDist = 0;	
				}
			}
		}
		if (currentDist >= maxStraightDist){
			turn();
			currentDist = 0;
		}
    }
	
	/**
     * Moves the jumper forward two steps, putting a blossom into the location it previously
     * occupied.
     */
    public void jump()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
            
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        Location next2 = next.getAdjacentLocation(getDirection());
        if (gr.isValid(next2))
            moveTo(next2);
            
        int lifetime = (int)(Math.random() * 20);
        Blossom blossom = new Blossom(lifetime);
        blossom.putSelfInGrid(gr, loc);
    }
	
	/**
     * Tests whether this bug can move forward into a location that is empty
     * @return true if this bug can move.
     */
    public boolean canJump()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return false;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        Location next2 = next.getAdjacentLocation(getDirection());
        if (!gr.isValid(next2))
            return false;
        
        Actor neighborTwoAway = gr.get(next2);
        return (neighborTwoAway == null);
        // ok to move into empty location
        // not ok to move onto any other actor
    }
    /**
     * Tests whether this bug can move forward into a location that is empty
     * @return true if this bug can move.
     */
    public boolean canMove()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return false;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (!gr.isValid(next))
            return false;
        Actor neighbor = gr.get(next);
        return (neighbor == null);
        // ok to move into empty location
        // not ok to move onto any other actor
    }
    
    /**
     * Moves the bug forward, putting a blossom into the location it previously
     * occupied.
     */
    public void move()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (gr.isValid(next))
            moveTo(next);
		int lifetime = (int)(Math.random() * 20);
		Blossom blossom = new Blossom(lifetime);
		blossom.putSelfInGrid(gr, loc);
    }
}
