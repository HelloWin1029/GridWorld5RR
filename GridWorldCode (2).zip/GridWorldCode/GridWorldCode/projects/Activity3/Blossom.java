import java.awt.Color;
import info.gridworld.actor.Flower;

public class Blossom extends Flower
{
	private int lifetime;
	
	public Blossom(){
		super(Color.GREEN);
		this.lifetime = 10;
	}
	
	public Blossom(int lifetime){
		super(Color.GREEN);
		this.lifetime = lifetime;
	}
	
	public void act(){
		super.act();
		lifetime--;
		if (lifetime <= 0)
			removeSelfFromGrid();
	}
}
