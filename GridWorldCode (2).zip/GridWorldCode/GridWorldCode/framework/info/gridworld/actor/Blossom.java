package info.gridworld.actor;

import java.awt.Color;

public class Blossom extends Flower
{
	private int lifetime;
	private int currentLife;
	
	public Blossom(){ lifetime = 10; }
	
	public Blossom(int steps){ lifetime = steps; }
	
	public void act(){
		if (currentLife == lifetime){
			removeSelfFromGrid();
			return;
		}
		super.act();
		currentLife++;
	}
}
