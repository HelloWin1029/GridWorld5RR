package info.gridworld.actor;

import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.Color;

public class Jumper extends Bug
{
	/**
     * Constructs a blue jumper.
     */
	public Jumper()
	{
		super(Color.BLUE);
	}
	
	/**
     * Moves if it can move, turns otherwise.
     */
    public void act()
    {
        if (canMove())
            move();
        else
            super.turn();
    }
	
	/**
     * Moves the jumper forward two steps, putting a blossom into the location it previously
     * occupied.
     */
    public void move()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        Location next2 = next.getAdjacentLocation(getDirection());
        if (gr.isValid(next2))
            moveTo(next2);
        else
            removeSelfFromGrid();
        Blossom blossom = new Blossom();
        blossom.putSelfInGrid(gr, loc);
    }
	
	/**
     * Tests whether this bug can move forward into a location that is empty or
     * contains a flower.
     * @return true if this bug can move.
     */
    public boolean canMove()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return false;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (!gr.isValid(next))
			return false;
			
        Location next2 = next.getAdjacentLocation(getDirection());
        if (!gr.isValid(next2))
            return false;
        
        Actor neighbor = gr.get(next2);
        return (neighbor == null);
        // ok to move into empty location
        // not ok to move onto any other actor
    }
}
